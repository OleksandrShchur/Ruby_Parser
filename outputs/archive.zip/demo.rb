require './biz/MainApplication.rb'

app = MainApplication::Application.new
app.run
